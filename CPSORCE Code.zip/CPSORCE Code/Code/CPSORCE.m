function [solution, Time] = gPSO_8(FileName,ParticleNumber,IterationNumber)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% gPSO main program for the detection of SNP-SNP interactions
% Input
%   pardata:        The particle number. for example, pardata = 50.
%   Dimensions:     The considered order of SNP-SNP interactions. 
%                   for example, Dimensions = 2
%   iteration:      The iteration number. for example, Iteration = 100.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %% Initialize Parameters ��ʼ����
filename=[FileName,'.mat'];
pardata=ParticleNumber;
Dimensions=2; 
iteration=IterationNumber;

%% Time Begin
% tic
%% Input data
temp = load(filename);
pts = temp.pts; % Dataset (sample * SNP) 
class = temp.class; % The phenotype of smaple
SNP = size(pts,2); % The number of SNPs
S = size(pts,1); % The number of samples


%% Problem specific variables 
G=5; %Number of groups 
M = 10; % The number of subsets 
Archive_x=cell(1,1,M);
Archive_x_mut=zeros(M,1);
End_mut=0;
End_x=cell(1,1);
%% Unimportant Parameters 
[~, snpdata] = size(pts);
% maximum particle position 
xmax = snpdata/M;
% minimum particle position 
xmin = 1;
% maximum particle velocity 
vmax =snpdata/M;
% minimum particle velocity 
vmin = -snpdata/M;
% the acceleration coefficients controlling 
c1 = 2.05;
c2 = 2.05;
% inertia weight
W=0.65;


%% The M subsets after random grouping 
sum_m = fix(SNP/M); % If m(i) < M, the number of SNPs in the i_th subset m(i) 
sum_M = SNP - (M-1) * sum_m; % If m(i) = M, the number of SNPs in the i_th subset m(i) 
L_m = max(sum_m,sum_M); % Select the largest value in m_1 and m_2 as the number of columns in m
m = zeros(S,L_m,M); % The M subsets after random grouping 

for g=1:G
    from = 1;
    to = sum_m;
    pts_ind = zeros(M,L_m);
    rowrank = randperm(size(pts,2));
    rand_pts = pts(:,rowrank);
    for s = 1 : M
       m(:,:,s) = rand_pts(:,from:to);
       pts_ind(s,:) = rowrank(from:to);
       from = from + sum_m;
       to = to + sum_m;
    end


%% initialize particle position 
par_x_index = cell(1,pardata,M);  
par_x = cell(1,pardata,M);   
par_mut = zeros(1,pardata,M);
for s=1:M
    for i = 1:1:pardata
        for j = 1:1:Dimensions
             par_x_index{1,i,s}(j) = round(1 + rand(1) * (xmax - 1) );
        end
        if par_x_index{1,i,s}(1) == par_x_index{1,i,s}(2)
               par_x_index{1,i,s}(2) = round(1 + rand(1) * (xmax - 1) );
        end
        pts_M=m(:,:,s);
        par_mut(1,i,s) = MutualInformation(pts_M,class,par_x_index{1,i,s});
    end
end


%% initialize particle velocity  
par_v = cell(1,pardata,M);  
for s = 1:M
    for i = 1:1:pardata 
        for j = 1:1:Dimensions
            par_v{1,i,s}(j) = round(vmin + (vmax - vmin) * rand(1));
        end
    end
end
%% initialize individual optimal solution 
par_pbest_x =cell(1,pardata,M);   
par_pbest_mut = zeros(1,pardata,M);
for s = 1:M
    for i = 1:1:pardata
        par_pbest_x{1,i,s} = par_x_index{1,i,s};
        par_pbest_mut(1,i,s) = par_mut(1,i,s);
    end
end

%% initialize historical position of neighbors of particle solution 
par_nbest_x=cell(1,1,M);
par_nbest_mut=zeros(M,1);
for s=1:M
    [par_nbest_mut(s,1),index]=max(par_pbest_mut(1,:,s));
    par_nbest_x(1,1,s)=par_pbest_x(1,index,s);
end
% end

%% Iteration
('Waitting...')
    for t = 1:1:iteration
        %% update particle velocity  
        for s=1:M
            for i = 1:1:pardata
                for j = 1:1:Dimensions   
                         par_v{1,i,s}(j) = W * par_v{1,i,s}(j) + c1 * rand(1) * (par_pbest_x{1,i,s}(j) - par_x_index{1,i,s}(j)) ...
                            + c2 * rand(1) * (par_nbest_x{1,1,s}(j)- par_x_index{1,i,s}(j));
                         par_v{1,i,s}(j) = round(par_v{1,i,s}(j));                
                end
            end
        end
        %% update particle position 
        for s=1:M
            for i = 1:1:pardata
                for j = 1:1:Dimensions
                    par_x_index{1,i,s}(j) = par_x_index{1,i,s}(j) + par_v{1,i,s}(j);
                    if par_x_index{1,i,s}(j) < xmin || par_x_index{1,i,s}(j) > xmax
                        par_x_index{1,i,s}(j) = xmin + round( ( xmax  - xmin) * rand(1) );
                    end 
                end
                pts_M=m(:,:,s);
                par_mut(1,i,s) = MutualInformation(pts_M,class,par_x_index{1,i,s});          
            end
        end
        %% update individual optimal solution 
        for s=1:M
            for i = 1:1:pardata
                for j = 1:1:Dimensions
                    if par_mut(1,i,s) > par_pbest_mut(1,i,s)
                        par_pbest_mut(1,i,s) = par_mut(1,i,s);
                        par_pbest_x{1,i,s} = par_x_index{1,i,s};
                    end
                end
            end
        end

    %% ����Ⱥ������
        for s=1:M
            for i = 1:1:pardata
                for j = 1:1:Dimensions
                    if par_mut(1,i,s)  > par_nbest_mut(s,1)
                        par_nbest_mut(s,1) = par_mut(1,i,s) ;
                        par_nbest_x(1,1,s) = par_x_index(1,i,s);
                    end
                end
            end
        end  
        
       %% ��Դ�������
        %% ����ÿ�����ƽ����Ӧ��ֵ������
        for s=1:M
            par_mut_SUM(1,s)=0;
            for i = 1:1:pardata
                par_mut_SUM(1,s)=par_mut_SUM(1,s)+par_mut(1,i,s);
            end
            par_mut_AVE(1,s)=par_mut_SUM(1,s)/pardata;
        end
        par_mut_AVE_Sort=sort(par_mut_AVE()); 
        par_nbest_mut_Sort=sort(par_nbest_mut());
        
        for s=1:M
            if par_mut_AVE(1,s)>par_mut_AVE_Sort(1,3) && par_nbest_mut(s,1)< par_nbest_mut_Sort(3,1)
                 %% update particle velocity             
                    for i = 1:1:pardata
                        for j = 1:1:Dimensions   
                                 par_v{1,i,s}(j) = W * par_v{1,i,s}(j) + c1 * rand(1) * (par_pbest_x{1,i,s}(j) - par_x_index{1,i,s}(j)) ...
                                    + c2 * rand(1) * (par_nbest_x{1,1,s}(j)- par_x_index{1,i,s}(j));
                                 par_v{1,i,s}(j) = round(par_v{1,i,s}(j));                
                        end
                    end                
                %% update particle position              
                    for i = 1:1:pardata
                        for j = 1:1:Dimensions
                            par_x_index{1,i,s}(j) = par_x_index{1,i,s}(j) + par_v{1,i,s}(j);
                            if par_x_index{1,i,s}(j) < xmin || par_x_index{1,i,s}(j) > xmax
                                par_x_index{1,i,s}(j) = xmin + round( ( xmax  - xmin) * rand(1) );
                            end 
                        end
                        pts_M=m(:,:,s);
                        par_mut(1,i,s) = MutualInformation(pts_M,class,par_x_index{1,i,s});          
                    end                
                %% update individual optimal solution            
                    for i = 1:1:pardata
                        for j = 1:1:Dimensions
                            if par_mut(1,i,s) > par_pbest_mut(1,i,s)
                                par_pbest_mut(1,i,s) = par_mut(1,i,s);
                                par_pbest_x{1,i,s} = par_x_index{1,i,s};
                            end
                        end
                    end              
                %% ����Ⱥ������              
                    for i = 1:1:pardata
                        for j = 1:1:Dimensions
                            if par_mut(1,i,s)  > par_nbest_mut(s,1)
                                par_nbest_mut(s,1) = par_mut(1,i,s) ;
                                par_nbest_x(1,1,s) = par_x_index(1,i,s);
                            end
                        end
                    end                
            end
        end                                
    end
    
    for s=1:M
        Archive_x(1,1,s)=par_nbest_x(1,1,s);
        Archive_x_mut(s,1)=par_nbest_mut(s,1);
    end

    Final_x(1,2000)=0;
    i=2*(g-1)*M+1;
    for s=1:M
       for j=1:Dimensions
                Final_x(1,i)=pts_ind(s,Archive_x{1,1,s}(j));
                i=i+1;
        end        
    end

    %% Final IterationNumber
    ('WAITING...')
    Final_x(find(Final_x==0))=[];
    Final_pts = pts(:,Final_x);
    L=length(Final_x(:));
    Finalxmax=L;
    Finalxmin=1;
    Finalvmin=-L;
    Finalvmax=L;

    %% Final initialize particle position 
    Final_par_x_index = cell(1,pardata);   
    Final_par_mut = zeros(1,pardata);
    for i = 1:1:pardata
        for j = 1:1:Dimensions
             Final_par_x_index{i}(j) = round(1 + rand(1) * (Finalxmax - 1) );
        end
        if Final_par_x_index{i}(1) == Final_par_x_index{i}(2)
               Final_par_x_index{i}(2) = round(1 + rand(1) * (Finalxmax - 1) );
        end
        Final_par_mut(i) = MutualInformation(Final_pts,class,Final_par_x_index{i});
    end


    %% Final initialize particle velocity  
    Final_par_v = cell(1,pardata);  

    for i = 1:1:pardata 
        for j = 1:1:Dimensions
            Final_par_v{i}(j) = round(Finalvmin + (Finalvmax - Finalvmin) * rand(1));
        end
    end

    %% Final initialize individual optimal solution 
    Final_par_pbest_x =cell(1,pardata);  
    Final_par_pbest_mut = zeros(1,pardata);
    for i = 1:1:pardata
        Final_par_pbest_x{i} = Final_par_x_index{i};
        Final_par_pbest_mut(i) = Final_par_mut(i);
    end

    %% Final initialize historical position of neighbors of particle solution 
    [Final_par_gbest_mut,index]=max(Final_par_pbest_mut);
    Final_par_gbest_x=Final_par_pbest_x(index);


    for T = 1:1:5
        %% update particle velocity  
        for i = 1:1:pardata
            for j = 1:1:Dimensions            
                    Final_par_v{i}(j) = W *Final_par_v{i}(j) + c1 * rand(1) * (Final_par_pbest_x{i}(j) - Final_par_x_index{i}(j)) ...
                        + c2 * rand(1) * (Final_par_gbest_x{1}(j)- Final_par_x_index{i}(j));
                     Final_par_v{i}(j) = round(Final_par_v{i}(j));

            end
        end

        %% update particle position 
        for i = 1:1:pardata
            for j = 1:1:Dimensions
                Final_par_x_index{i}(j) = Final_par_x_index{i}(j) + Final_par_v{i}(j);
                if Final_par_x_index{i}(j) < Finalxmin || Final_par_x_index{i}(j) > Finalxmax
                    Final_par_x_index{i}(j) = Finalxmin + round( ( Finalxmax  - Finalxmin) * rand(1) );
                end 
            end
            Final_par_mut(i) = MutualInformation(Final_pts,class,Final_par_x_index{i});

        end

        %% update individual optimal solution 
        for i = 1:1:pardata
            for j = 1:1:Dimensions
                if Final_par_mut(i) > Final_par_pbest_mut(i)
                    Final_par_pbest_mut(i) = Final_par_mut(i);
                    Final_par_pbest_x(i) = Final_par_x_index(i);
                end
            end
        end

        for i = 1:1:pardata
            for j = 1:1:Dimensions
                if Final_par_mut(i) > Final_par_gbest_mut
                    Final_par_gbest_mut = Final_par_mut(i);
                    Final_par_gbest_x = Final_par_x_index(i);
                end
            end
        end
    end
    if Final_par_gbest_mut>End_mut
        End_mut=Final_par_gbest_mut;
        End_x=Final_par_gbest_x;
    end
end

     solution{1}(1)= Final_x(1,End_x{1}(1));
     solution{1}(2)= Final_x(1,End_x{1}(2));

%% Time End
Time=toc; 
save all
SaveName=[FileName,'_',num2str(ParticleNumber),'_',num2str(IterationNumber),'.mat'];
save(SaveName,'solution');

function MI=MutualInformation(pts,class,factor)
% Compute Mutual Information between class label and a SNP set.
% MI(X;C)=H(X)+H(C)-H(X,C), where C is the class label and X is a SNP set.
data=pts(:,factor);
MI=Func_MutualInfo(double(data)',double(class));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MI=Func_MutualInfo(data,labels)
% Jan.19 2007 By Guoqiang Yu
%--- INPUT
% data:  features x samples; note that the 
% value of zero indicates a missing data 
% labels: the label matrix of each sample;  
%--- OUTPUT
% MI: Information provided by the features 
%%
data=data-min(data(:));          %minimum data is 0
labels=labels-min(labels(:))+1; %minimum label is 1

Num_Label=max(labels(:));
Num_DataType=max(data(:))+1;
[Num_Feature,Num_Sample]=size(data);

%Entropy of the random variable Label 
H_Label=hist(labels,Num_Label);
P_Label=H_Label/Num_Sample;
Entropy_Label=-P_Label*log2(P_Label'+eps);

%Special dealing with the case of small Num_Feature 
if Num_Feature<9
    ZZ=Num_DataType.^(Num_Feature-1:-1:0)';
    Hist_Label=zeros(Num_DataType^Num_Feature,Num_Label);%  Hist_Label is p(c,f)
    tempIndex=ZZ'*data+1;
    for j=1:Num_Sample
        Hist_Label(tempIndex(j),labels(j))=Hist_Label(tempIndex(j),labels(j))+1; % calculate p(c,f) 
    end
    
    sumHist=sum(Hist_Label,2);   %calculate p(f)
    repHist=repmat(sumHist,1,Num_Label); 
    pHist_Label=Hist_Label./(repHist+eps);%p(c/f)=p(c,f)/p(f).
    InfoIncre=-sum((log2(pHist_Label+eps).*pHist_Label).*(repHist));
    MI=Entropy_Label-sum(InfoIncre)/Num_Sample;
    return;
end

%Larger Feature Number follows the following procedure 
mm=1;
Hist_Label=zeros(Num_Label,Num_Sample);
Hist_Label(labels(1,1),mm)=1;
Hist_SNP=zeros(Num_Feature,Num_Sample);
Hist_SNP(:,mm)=data(:,1);

for j=2:Num_Sample
    tempData=data(:,j);
    Index=0;
    for k=1:mm
        if isequal(Hist_SNP(:,k),tempData)
            Index=k;
            break;
        end
    end
    if Index==0
        mm=mm+1;
        Hist_SNP(:,mm)=tempData;
        Hist_Label(labels(j,1),mm)=1;
    else
        Hist_Label(labels(j,1),Index)=Hist_Label(labels(j,1),Index)+1;
    end
end

M1=mm;
InfoIncre=0;
for s=1:M1
    tempNum=sum(Hist_Label(:,s));
    P=Hist_Label(:,s)/tempNum;
    InfoIncre=InfoIncre-P'*log2(P+eps)*tempNum;
end
MI=Entropy_Label-InfoIncre/Num_Sample;ss